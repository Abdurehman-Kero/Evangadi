
$(function () {
  // Define the function that sets up the footer toggle behavior
  function attachToggle() {
    // If the screen width is 768px or less → mobile mode
    if ($(window).width() <= 768) {
      // Remove any old click events, then add a new click event on <h3>
      $(".footer-links-wrapper h3")
        .off("click")
        .on("click", function () {
          // Slide toggle (show/hide) the <ul> after this <h3>
          $(this).next("ul").slideToggle();

          // Toggle a CSS class to change the icon style (from + to ×)
          $(this).toggleClass("iconRotator");
        });

      // On mobile, ensure all sections start closed (or you can choose to keep some open)
      $(".footer-links-wrapper ul").hide();
      $(".footer-links-wrapper h3").removeClass("iconRotator");
    } else {
      // Otherwise → desktop/tablet mode

      // Always show all footer <ul> lists
      $(".footer-links-wrapper ul").show();
      // Remove any click events from <h3> (no collapsible behavior on desktop)
      $(".footer-links-wrapper h3").off("click");
      // Remove the rotation class on desktop
      $(".footer-links-wrapper h3").removeClass("iconRotator");
    }
  }

    attachToggle(); // Call the function immediately when the page loads

  // Also call the function whenever the window is resized
  // (so it switches between mobile and desktop behavior correctly)
  $(window).resize(function () {
    attachToggle();
  });
});
